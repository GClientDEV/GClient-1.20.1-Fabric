
    // HitBox class

package net.gtx550ti.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class HitBox {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static double size = 0.35;

    public static void initialize() {
        WorldRenderEvents.BEFORE_ENTITIES.register(context -> {
            if (mc.world == null || mc.player == null) return;
            for (Entity entity : mc.world.getEntities()) {
                if (entity instanceof PlayerEntity && entity != mc.player) {
                    entity.setBoundingBox(new Box(
                        entity.getX() - size,
                        entity.getBoundingBox().minY,
                        entity.getZ() - size,
                        entity.getX() + size,
                        entity.getBoundingBox().maxY,
                        entity.getZ() + size
                    ));
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("private")
                .then(ClientCommandManager.literal("htibox")
                .then(ClientCommandManager.literal("size")
                .then(ClientCommandManager.literal("=")
                .then(ClientCommandManager.argument("size", DoubleArgumentType.doubleArg(0.1, 10.0))
                    .executes(context -> {
                        double newSize = DoubleArgumentType.getDouble(context, "size");
                        size = newSize;
                        context.getSource().getPlayer().sendMessage(
                            Text.of("§7[§fGClient Client§7] §cHitBox §8-> §fValue changed! New value is §c" + size), true
                        );
                        return 1;
                    })
                )))));
        });
    }
}