
    // TriggerBot class

package net.gtx550ti.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.Hand;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class TriggerBot {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static boolean TriggerBot = false; 
    private static boolean onlyCrits = true;
    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (TriggerBot && mc.world != null && mc.player != null && mc.crosshairTarget != null) {
                if (mc.crosshairTarget instanceof EntityHitResult hitResult) {
                    if (hitResult.getEntity() instanceof LivingEntity target && target != mc.player && canAttack(target)) {
                        performAttack(target);
                    }
                }
            }
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("private")
                .then(ClientCommandManager.literal("TriggerBot")
                .then(ClientCommandManager.literal("toggle")
                .executes(context -> {
                    TriggerBot = !TriggerBot;
                    context.getSource().getPlayer().sendMessage(
                        Text.of("§7[§fGClient§7] §fTriggerBot §8-> " + (TriggerBot ? "§aON" : "§cOFF")), true
                    );
                    return 1;
                })
                )));
        });
    }
    private static boolean canAttack(LivingEntity target) {
        if (target == null || target == mc.player || !target.isAttackable() || target.isDead()) {
            return false;
        }
        if (mc.player.getAttackCooldownProgress(0.5F) < 0.93F) {
            return false;
        }
        boolean isInAir = !mc.player.isOnGround();
        ItemStack mainHandStack = mc.player.getMainHandStack();
        boolean isHoldingSword = mainHandStack.getItem() == Items.NETHERITE_SWORD ||
                                 mainHandStack.getItem() == Items.DIAMOND_SWORD;

        boolean reasonForAttack = mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
            || mc.player.isClimbing()
            || (mc.player.isTouchingWater() && mc.player.isSubmergedIn(FluidTags.WATER))
            || mc.player.hasVehicle()
            || mc.player.getAbilities().flying
            || mc.player.isFallFlying();
        if (onlyCrits) {
            return isInAir && isHoldingSword && !reasonForAttack;
        }

        return isHoldingSword && !reasonForAttack;
    }

    private static void performAttack(LivingEntity target) {
        if (mc.interactionManager != null && mc.player != null) {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}