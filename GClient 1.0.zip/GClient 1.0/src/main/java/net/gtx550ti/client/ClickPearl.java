
    // ClickPeal class

package net.gtx550ti.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClickPearl {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static KeyBinding middleClickPearlKey;

    public static void initialize() {
        middleClickPearlKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "ClickPearl",
            InputUtil.Type.MOUSE,
            GLFW.GLFW_MOUSE_BUTTON_MIDDLE,
            "GClient Client Utils"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (middleClickPearlKey.wasPressed()) {
                handleMiddleClick();
            }
        });
    }

    private static void handleMiddleClick() {
        ItemStack enderPearlStack = findEnderPearlInInventory();
        if (enderPearlStack != null && !mc.player.getItemCooldownManager().isCoolingDown(Items.ENDER_PEARL)) {
            int pearlSlot = findSlotOfItemStack(enderPearlStack);
            if (pearlSlot != -1) {
                sendHeldItemChangePacket(pearlSlot);
                useItem(Hand.MAIN_HAND);
                sendHeldItemChangePacket(mc.player.getInventory().selectedSlot);
            }
        }
    }

    private static ItemStack findEnderPearlInInventory() {
        PlayerInventory inventory = mc.player.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stackInSlot = inventory.getStack(i);
            if (!stackInSlot.isEmpty() && stackInSlot.getItem() == Items.ENDER_PEARL) {
                return stackInSlot;
            }
        }
        return null;
    }

    private static int findSlotOfItemStack(ItemStack stack) {
        PlayerInventory inventory = mc.player.getInventory();
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stackInSlot = inventory.getStack(i);
            if (!stackInSlot.isEmpty() && ItemStack.areEqual(stack, stackInSlot)) {
                return i;
            }
        }
        return -1;
    }

    private static void sendHeldItemChangePacket(int itemSlot) {
        mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(itemSlot));
    }

    private static void useItem(Hand hand) {
        int sequence = mc.player.getInventory().getEmptySlot();
        mc.player.networkHandler.sendPacket(new PlayerInteractItemC2SPacket(hand, sequence));
    }
}