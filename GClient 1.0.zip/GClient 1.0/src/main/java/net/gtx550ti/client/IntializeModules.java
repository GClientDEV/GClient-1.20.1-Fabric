package net.gtx550ti.client;

import net.fabricmc.api.ClientModInitializer;

public class IntializeModules implements ClientModInitializer{
    public void onInitializeClient() {

        // Initializing other classes

        ClickPearl.initialize();
        TriggerBot.initialize();
        AutoSprint.initialize(); 
        HitBox.initialize();
    }
}