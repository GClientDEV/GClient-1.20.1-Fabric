
    // AutoSprint class

package net.gtx550ti.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class AutoSprint {
    private static boolean AutoSprint = false;
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (mc.world == null || mc.player == null) return;
            if (AutoSprint) {
                mc.player.setSprinting(true);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("private")
                .then(ClientCommandManager.literal("AutoSprint")
                .then(ClientCommandManager.literal("toggle")
                .executes(context -> {
                    AutoSprint = !AutoSprint;
                    context.getSource().getPlayer().sendMessage(
                        Text.of("§7[§fGClient Client§7] §fAutoSprint §8-> " + (AutoSprint ? "§aON" : "§cOFF")), true
                    );
                    return 1;
                })
                )));
        });
    }
}